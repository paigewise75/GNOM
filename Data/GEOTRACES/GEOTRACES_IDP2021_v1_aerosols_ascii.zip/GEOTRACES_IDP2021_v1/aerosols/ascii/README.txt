ASCII Version of GEOTRACES IDP2021

Extract the data file by unpacking the .zip file.

October 2021
Reiner Schlitzer
