ASCII Version of GEOTRACES IDP2021

Extract the data file by unpacking the .zip file.

Please note that the unzipped data file is very large (> 0.5 GB).

You can obtain subsets of the GEOTRACES IDP2021 data for smaller
domains, individual cruises or specific parameters via an online data
extraction service at https://geotraces.webodv.awi.de/. This site also
lets you explore and visualize the data without the need to download
the data or install software.

October 2021
Reiner Schlitzer
