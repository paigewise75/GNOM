ODV Version of GEOTRACES IDP2021

You need Ocean Data View (ODV) version 5.1.0 or later to open this
collection. ODV for Windows, MacOS or Linux is available for download
at https://odv.awi.de/.

You can obtain subsets of the GEOTRACES IDP2021 data for smaller
domains, individual cruises or specific parameters via an online data
extraction service at https://geotraces.webodv.awi.de/. This site also
lets you explore and visualize the data without the need to download
the data or install software.

October 2021
Reiner Schlitzer
