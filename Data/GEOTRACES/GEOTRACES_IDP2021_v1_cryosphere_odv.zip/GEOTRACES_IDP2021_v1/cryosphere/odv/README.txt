ODV Version of GEOTRACES IDP2021

You need Ocean Data View (ODV) version 5.1.0 or later to open this
collection. ODV for Windows, MacOS or Linux is available for download
at https://odv.awi.de/.

October 2021
Reiner Schlitzer
