netCDF Version of GEOTRACES IDP2021

Extract the netcdf file by unpacking the .zip file.

Please see "nc_info.txt" for an overview of structure and content of
the netCDF file. See "nc_variables.txt" for a list of netCDF variable
names and their associated GEOTRACES variable names.

October 2021
Reiner Schlitzer
